﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Mvc4_WebGrid_CRUD.Models;

namespace Mvc4_WebGrid_CRUD.Controllers
{
    public class HomeController : Controller
    {
        ModelServices mobjModel = new ModelServices();

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Demo()
        {
            Response.Redirect("http://www.dotnet-tricks.com/Tutorial/mvclist");
            return View();
        }

        public ActionResult WebGridCRUD(int page = 1, string sort = "custid", string sortDir = "ASC")
        {
            const int pageSize = 10;
            var totalRows = mobjModel.CountCustomer();

            bool Dir = sortDir.Equals("desc", StringComparison.CurrentCultureIgnoreCase) ? true : false;

            var customer = mobjModel.GetCustomerPage(page, pageSize, sort, Dir);
            var data = new PagedCustomerModel()
            {
                TotalRows = totalRows,
                PageSize = pageSize,
                Customer = customer
            };
            return View(data);
        }

        [HttpGet]
        public JsonResult UpdateRecord(int id, string name, string address, string contactno)
        {
            bool result = false;
            try
            {
                result = mobjModel.UpdateCustomer(id, name, address, contactno);

            }
            catch (Exception ex)
            {
            }
            return Json(new { result }, JsonRequestBehavior.AllowGet);
        }

      [HttpGet]
        public JsonResult SaveRecord(string name, string address, string contactno)
        {
            bool result = false;
            try
            {
                result = mobjModel.SaveCustomer(name, address, contactno);

            }
            catch (Exception ex)
            {
            }
            return Json(new { result }, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public JsonResult DeleteRecord(int id)
        {
            bool result = false;
            try
            {
                result = mobjModel.DeleteCustomer(id);

            }
            catch (Exception ex)
            {
            }
            return Json(new { result }, JsonRequestBehavior.AllowGet);
        }

    }
}
